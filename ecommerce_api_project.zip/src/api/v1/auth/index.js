const signin = require("./controllers/signin");

module.exports = {signin}